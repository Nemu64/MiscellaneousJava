This is version 3 (and very likely the last version) of the Final Project. The main method is still in NewInputWindow

Things that have changed:
- You can now minimize all windows (except errors and file pickers) to the taskbar
- You can now use the keyboard to press the buttons (Space / Enter is the same as clicking)
- You can clear all fields with the "Clear" button
- You can change themes on the fly with the theme change button (the initial theme is picked automatically based on the OS)
- The help text now updates when tabbing to a field as well as on mouse hover
- Windows are now centered on the screen istead appearing in the top left
- Click the X on the "Is this correct?" window takes you back to the main window. It's equivalent to clicking No
- Lots and lots of comments added
- Many qualified names have been replaced with imports
- Drastically reduced the jar size. It's now only 50kb
- Added an easter egg :)