public class chapter2_prob8_InchesToFeet {

		public static void main(String[] args) {
			final int INCHES_IN_FEET = 12;
			int totalinches = 87;
			System.out.print(totalinches + " inches is equivalent to " + (totalinches / INCHES_IN_FEET) + " feet and " + (totalinches % INCHES_IN_FEET) + " inches.");
		}
}
