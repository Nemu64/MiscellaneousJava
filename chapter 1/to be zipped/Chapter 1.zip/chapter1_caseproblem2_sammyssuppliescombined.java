package sammyssupplies;
import javax.swing.JOptionPane;

public class sammyssupplies {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Sammy’s makes it fun in the sun.");
		JOptionPane.showMessageDialog(null, "SsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsS\nS Carly’s makes the food that makes it a party.  S\nSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsSsS");
	}

}
