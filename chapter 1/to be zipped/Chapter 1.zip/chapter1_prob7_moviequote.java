
public class moviequote {
	public static void main(String[] args) {
		System.out.println("\"Well you left the TV on, and your cat is dead.\"\n-- Dwight Schrute, 2007");

	}

}
