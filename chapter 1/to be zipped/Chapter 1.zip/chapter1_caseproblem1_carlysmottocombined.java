package carlysmotto;
import javax.swing.JOptionPane;

public class carlysmotto {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Carly’s makes the food that makes it a party.");
		JOptionPane.showMessageDialog(null, "******************************************************\n* Carly’s makes the food that makes it a party. *\n******************************************************");
	}

}
