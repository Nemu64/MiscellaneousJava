package fixfour;
import javax.swing.JOptionPane; 

public class fixfour {
	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "First GUI program");
	}
}