import javax.swing.*;

public class NewInputWindow extends JDialog {

    public NewInputWindow(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }
    private void initComponents() {

        quiz2label = new JLabel();
        quiz3label = new JLabel();
        test1 = new JTextField();
        test2 = new JTextField();
        test3 = new JTextField();
        quiz4label = new JLabel();
        quiz1 = new JTextField();
        quiz2 = new JTextField();
        quiz3 = new JTextField();
        quiz4 = new JTextField();
        namelabel = new JLabel();
        name = new JTextField();
        hwlabel = new JLabel();
        okbutton = new JButton();
        hwgrade = new JTextField();
        cancelbutton = new JButton();
        attendancelabel = new JLabel();
        collegelabel = new JLabel();
        attendance = new JTextField();
        collegename = new JTextField();
        test1label = new JLabel();
        test2label = new JLabel();
        test3label = new JLabel();
        test4label = new JLabel();
        test4 = new JTextField();
        quiz1label = new JLabel();
        statusbar = new JLabel();
        jSeparator1 = new JSeparator();

        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Grade Calculator");
        setName("dialog");
        setResizable(false);
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Hover an item for details");
            }
        });
        quiz2label.setText("Quiz 2 Score");
        quiz3label.setText("Quiz 3 Score");
        test1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Enter your score for Test 1 here. (0-100)");
            }
        });

        test2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Enter your score for Test 2 here. (0-100)");
            }
        });

        test3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Enter your score for Test 3 here. (0-100)");
            }
        });

        quiz4label.setText("Quiz 4 Score");

        quiz1.setActionCommand("<Not Set>");
        quiz1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Enter your score for Quiz 1 here. (0-100)");
            }
        });

        quiz2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Enter your score for Quiz 2 here. (0-100)");
            }
        });

        quiz3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Enter your score for Quiz 3 here. (0-100)");
            }
        });

        quiz4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Enter your score for Quiz 4 here. (0-100)");
            }
        });

        namelabel.setText("Name: ");
        name.setText(System.getProperty("user.name"));
        name.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus(nameboxhelptext);
            }
        });
        name.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nameboxhelptext = "Enter your full name here.";
                setStatus(nameboxhelptext);
            }
        });

        hwlabel.setText("HW Grade");

        okbutton.setText("OK");
        okbutton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dialog.setVisible(false);
                verifyAndPassData();
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Click this button to continue.");
            }
        });

        hwgrade.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Enter your final homework grade here. (0-100)");
            }
        });

        cancelbutton.setText("Cancel");
        cancelbutton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                confirmExit();
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Click this button to exit.");
            }
        });

        attendancelabel.setText("Attendance");

        collegelabel.setText("The college I want to attend is: ");

        attendance.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Enter your final attendance grade here. (0-100)");
            }
        });

        collegename.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Enter the college you want to attend here.");
            }
        });

        test1label.setText("Test 1 Score");

        test2label.setText("Test 2 Score");

        test3label.setText("Test 3 Score");

        test4label.setText("Test 4 Score");

        test4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                setStatus("Enter your score for Test 4 here. (0-100)");
            }
        });

        quiz1label.setText("Quiz 1 Score");
        statusbar.setText("Watch here for important information");
        statusbar.setToolTipText("Watch here for important information");
        statusbar.setFocusable(false);

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(namelabel)
                .addGap(12, 12, 12)
                .addComponent(name, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(collegelabel)
                .addGap(6, 6, 6)
                .addComponent(collegename, GroupLayout.PREFERRED_SIZE, 145, GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(test1label)
                .addGap(6, 6, 6)
                .addComponent(test1, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(quiz1label)
                .addGap(6, 6, 6)
                .addComponent(quiz1, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(test2label)
                .addGap(6, 6, 6)
                .addComponent(test2, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(quiz2label)
                .addGap(6, 6, 6)
                .addComponent(quiz2, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(test3label)
                .addGap(6, 6, 6)
                .addComponent(test3, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(quiz3label)
                .addGap(6, 6, 6)
                .addComponent(quiz3, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(okbutton)
                .addGap(6, 6, 6)
                .addComponent(cancelbutton))
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(statusbar))
            .addComponent(jSeparator1, GroupLayout.PREFERRED_SIZE, 350, GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(test4label)
                        .addGap(6, 6, 6))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(hwlabel)
                        .addGap(14, 14, 14)))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                    .addComponent(hwgrade, GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                    .addComponent(test4))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(quiz4label)
                        .addGap(6, 6, 6)
                        .addComponent(quiz4, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE))
                    .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(attendancelabel)
                        .addGap(10, 10, 10)
                        .addComponent(attendance, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(namelabel))
                    .addComponent(name, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(collegelabel))
                    .addComponent(collegename, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(test1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(quiz1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(test1label)
                            .addComponent(quiz1label))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(test2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(quiz2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(test2label)
                            .addComponent(quiz2label))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(test3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(quiz3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(test3label)
                            .addComponent(quiz3label))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(test4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(quiz4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(test4label)
                            .addComponent(quiz4label))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(attendance, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(hwlabel)
                                .addComponent(hwgrade, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                            .addComponent(attendancelabel))))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(okbutton)
                    .addComponent(cancelbutton))
                .addGap(1, 1, 1)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(statusbar)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jSeparator1, GroupLayout.PREFERRED_SIZE, 10, GroupLayout.PREFERRED_SIZE))))
        );

        pack();
    }
    static NewInputWindow dialog = new NewInputWindow(new JFrame(), true);
    public static void main(String args[]) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewInputWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewInputWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewInputWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewInputWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        confirmExit();
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
    public static void confirmExit() {
        if (JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?","Really exit?",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) System.exit(0);
    }
    public void setStatus(String status) {
        statusbar.setText(status);
    }
    public void verifyAndPassData() {
        if (name.getText().isBlank() || collegename.getText().isBlank()) {
            errorOccured();
            return;
        }
        Grades.studentName = name.getText();
        Grades.collegeName = collegename.getText();
        JTextField[] checkthese = {test1, test2, test3, test4, quiz1, quiz2, quiz3, quiz4, hwgrade, attendance};
        try {
            Grades.test1 = Float.valueOf(checkthese[0].getText());
            Grades.test2 = Float.valueOf(checkthese[1].getText());
            Grades.test3 = Float.valueOf(checkthese[2].getText());
            Grades.test4 = Float.valueOf(checkthese[3].getText());
            Grades.quiz1 = Float.valueOf(checkthese[4].getText());
            Grades.quiz2 = Float.valueOf(checkthese[5].getText());
            Grades.quiz3 = Float.valueOf(checkthese[6].getText());
            Grades.quiz4 = Float.valueOf(checkthese[7].getText());
            Grades.hwGrade = Float.valueOf(checkthese[8].getText());
            Grades.attendanceGrade = Float.valueOf(checkthese[9].getText());
        }
        catch (NumberFormatException e) {
            errorOccured();
            return;
        }
        new NewIsCorrectWindow(dialog).setVisible(true);
    }
    public static void errorOccured() {
        JOptionPane.showMessageDialog(dialog, "Something is not right.\nCheck to make sure you filled in all data fields with the proper data type.", "Error occured", JOptionPane.ERROR_MESSAGE);
        dialog.setVisible(true);
    }
    private String nameboxhelptext = "We autofilled your name. If this is not correct, please fix it.";
    private JTextField attendance;
    private JLabel attendancelabel;
    private JButton cancelbutton;
    private JLabel collegelabel;
    private JTextField collegename;
    private JTextField hwgrade;
    private JLabel hwlabel;
    private JSeparator jSeparator1;
    static JTextField name;
    private JLabel namelabel;
    private JButton okbutton;
    private JTextField quiz1;
    private JLabel quiz1label;
    private JTextField quiz2;
    private JLabel quiz2label;
    private JTextField quiz3;
    private JLabel quiz3label;
    private JTextField quiz4;
    private JLabel quiz4label;
    private JLabel statusbar;
    private JTextField test1;
    private JLabel test1label;
    private JTextField test2;
    private JLabel test2label;
    private JTextField test3;
    private JLabel test3label;
    private JTextField test4;
    private JLabel test4label;
}