import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
public class AverageOfInts {
	public static Scanner keyboard = new Scanner(System.in);
	public static Integer nums[] = {};
	public static ArrayList<Integer> numberarray = new ArrayList<Integer>(Arrays.asList(nums));
	public static void main(String[] args) {
		getNumbers();
	}
	public static void getNumbers() {
		System.out.print("\n\nEnter a number, type \"delete\" to delete a number, or tyoe \"done\" to calculate the average: ");
		String numtoadd = keyboard.next();
		if (numtoadd.toLowerCase().contentEquals("done")) {
			getAverage();
			System.exit(0);
		}
		else if (numtoadd.toLowerCase().contentEquals("delete") && nums.length > 0) {
			deleteNumber();
		}
		else if (numtoadd.toLowerCase().contentEquals("delete")) {
			System.out.print("The number list is blank, so you can't delete anything.");
			getNumbers();
		}
		else {
			if (numberarray.contains(Integer.parseInt(numtoadd))) {
				System.out.print("That number is already in the list. Do you want to add it again? (y/n) ");
				if (keyboard.next().toLowerCase().contentEquals("y")) {
					numberarray.add(Integer.parseInt(numtoadd));  
					nums = numberarray.toArray(nums);
					System.out.print("\nCurrent numbers: " + Arrays.toString(nums));
					getNumbers();
				}
				else {
					System.out.print("\nCurrent numbers: " + Arrays.toString(nums));
					getNumbers();
				}
			}
			else {
				numberarray.add(Integer.parseInt(numtoadd));  
				nums = numberarray.toArray(nums);
				System.out.print("\nCurrent numbers: " + Arrays.toString(nums));
				getNumbers();
			}
		}
	}
	
	public static int sumNumbers() {
		int finaltotal = 0;
		for (int x = 0; x < nums.length; x++) {
			if (nums[x] != null) {
				finaltotal += nums[x];
			}
		}
		return finaltotal;
	}
	
	public static void deleteNumber() {
		if (nums.length == 0) {
			System.out.print("The number list is blank, so you can't delete anything.");
			getNumbers();		
		}
		System.out.print("\nCurrent numbers: " + Arrays.toString(nums) + "\nType the number you want to delete, or type \"done\" to exit delete mode: ");
		String numtoadd = keyboard.next();
		if (numtoadd.toLowerCase().contentEquals("done")) {
			getNumbers();
		}
		else {
			if (numberarray.contains(Integer.parseInt(numtoadd))) {
				numberarray.remove(numberarray.indexOf(Integer.parseInt(numtoadd)));
				nums = numberarray.toArray(nums);
				nums = Arrays.copyOf(nums, nums.length - 1);
				deleteNumber();
			}
			else {
				System.out.print("\nThat number is not in the list.");
				deleteNumber();
			}
		}
	}

	public static void getAverage() {
		if (nums.length < 2) {
			System.out.print("You need at least 2 numbers to compute an average.");
			getNumbers();
		}
		else {
			System.out.print("The average of the number list is " + ((double)sumNumbers() / nums.length));
		}
	}

}
