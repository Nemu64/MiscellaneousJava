public class chapter2_prob10_Initials {

	public static void main(String[] args) {
		String finitial = "J";
		String minitial = "M";
		String linitial = "B";
		System.out.print(finitial + "." + minitial + "." + linitial + ".");
	}
}
