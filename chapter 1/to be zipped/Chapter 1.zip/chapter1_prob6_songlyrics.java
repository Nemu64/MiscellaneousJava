package songlyrics;

public class songlyrics {
	public static void main(String[] args) {
		System.out.println("She's got a smile it seems to me\nReminds me of childhood memories\nWhere everything was as fresh as the bright blue sky\nNow and then when I see her face\nShe takes me away to that special place\nAnd if I'd stare too long\nI'd probably break down and cry");
	}
}
