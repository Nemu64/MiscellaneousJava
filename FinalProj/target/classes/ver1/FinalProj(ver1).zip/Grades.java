import java.io.FileWriter;
import java.io.IOException;

public class Grades {
    static String studentName;
    static String collegeName;
    static float test1;
    static float test2;
    static float test3;
    static float test4;
    static float quiz1;
    static float quiz2;
    static float quiz3;
    static float quiz4;
    static float hwGrade;
    static float attendanceGrade;


    public static float getTestAverage() {
        return (test1 + test2 + test3 + test4) / 4;
    }

    public static float getQuizAverage() {
        return (quiz1 + quiz2 + quiz3 + quiz4) / 4;
    }

    public static float getOverallGrade() {
        return (float) ((getTestAverage() * .6) + (getQuizAverage() * .2) + (hwGrade * .1) + (attendanceGrade * .1));
    }

    public static char getLetterGrade(float overallavg) {
        if (overallavg >= 90) return 'A';
        else if (overallavg >= 80) return 'B';
        else if (overallavg >= 70) return 'C';
        else if (overallavg >= 60) return 'D';
        else return 'F';
    }

    public static int getGPA(char letter) {
        switch (letter) {
            case 'A' -> {
                return 4;
            }
            case 'B' -> {
                return 3;
            }
            case 'C' -> {
                return 2;
            }
            case 'D' -> {
                return 1;
            }
            case 'F' -> {
                return 0;
            }
        }
        return letter;
    }

    public static String saveResults() {
        try {
            FileWriter fw = new FileWriter("results.txt");
            fw.write("Student name: " + studentName +
                "\nCollege name: " + collegeName +
                "\nTest average: " + getTestAverage() +
                "\nQuiz average: " + getQuizAverage() +
                "\nOverall average: " + getOverallGrade() +
                "\nLetter grade: " + getLetterGrade(getOverallGrade()) +
                "\nGPA: " + getGPA(getLetterGrade(getOverallGrade())));
        }
        catch (IOException e) {}
        return "These results have been saved to results.txt";
    }
}