import javax.swing.*;
public class NewResultsWindow extends JFrame {

    public NewResultsWindow() {

        resultslabel = new JLabel();
        testavg = new JLabel();
        quizavg = new JLabel();
        gpa = new JLabel();
        overallavg = new JLabel();
        lettergrade = new JLabel();
        withhonors = new JLabel();
        college = new JLabel();
        filesavedhere = new JLabel();
        overallavgtxt = new JLabel();
        gpatxt = new JLabel();
        quizavgtxt = new JLabel();
        testavgtxt = new JLabel();
        lettergradetxt = new JLabel();
        closebutton = new JButton();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        resultslabel.setFont(new java.awt.Font("Segoe UI", 1, 24));
        resultslabel.setHorizontalAlignment(SwingConstants.CENTER);
        resultslabel.setText("These are your results");

        testavg.setText("Your test average: ");

        quizavg.setText("Your quiz average: ");

        gpa.setText("Your GPA: ");

        overallavg.setFont(new java.awt.Font("Segoe UI", 1, 12));
        overallavg.setText("Your overall average: ");

        lettergrade.setFont(new java.awt.Font("Segoe UI", 1, 12));
        lettergrade.setText("Letter grade: ");

        withhonors.setFont(new java.awt.Font("Segoe UI", 1, 12));
        withhonors.setText((Grades.getOverallGrade() >= 90) ? "You will graduate with honors!" : "");

        college.setFont(new java.awt.Font("Segoe UI", 1, 12));
        college.setText((Grades.getOverallGrade() >= 90) ? "You will go to " + Grades.collegeName + "!" : "");

        filesavedhere.setFont(new java.awt.Font("Segoe UI", 1, 12));
        filesavedhere.setText(Grades.saveResults());

        overallavgtxt.setFont(new java.awt.Font("Segoe UI", 1, 12));
        overallavgtxt.setText(String.valueOf(Grades.getOverallGrade()));

        gpatxt.setText(String.valueOf(Grades.getGPA(Grades.getLetterGrade(Grades.getOverallGrade()))));

        quizavgtxt.setText(String.valueOf(Grades.getQuizAverage()));

        testavgtxt.setText(String.valueOf(Grades.getTestAverage()));

        lettergradetxt.setFont(new java.awt.Font("Segoe UI", 1, 12));
        lettergradetxt.setText(String.valueOf(Grades.getLetterGrade(Grades.getOverallGrade())));

        closebutton.setText("Close");
        closebutton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closebuttonMouseClicked(evt);
            }
        });

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(resultslabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(filesavedhere)
                            .addComponent(college)
                            .addComponent(withhonors)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                    .addComponent(overallavg)
                                    .addComponent(gpa)
                                    .addComponent(quizavg)
                                    .addComponent(testavg)
                                    .addComponent(lettergrade))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                    .addComponent(lettergradetxt)
                                    .addComponent(testavgtxt)
                                    .addComponent(quizavgtxt)
                                    .addComponent(gpatxt)
                                    .addComponent(overallavgtxt)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addComponent(closebutton, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(resultslabel)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(testavg)
                    .addComponent(testavgtxt))
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(quizavg)
                    .addComponent(quizavgtxt))
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(gpa)
                    .addComponent(gpatxt))
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(overallavg)
                    .addComponent(overallavgtxt))
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lettergrade)
                    .addComponent(lettergradetxt))
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(withhonors)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(college)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(filesavedhere)
                .addGap(18, 18, 18)
                .addComponent(closebutton)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        pack();
    }

    private void closebuttonMouseClicked(java.awt.event.MouseEvent evt) {
        resultslabel.setText("Goodbye!");
        resultslabel.paintImmediately(resultslabel.getVisibleRect());
        try {Thread.sleep(1500);} catch (InterruptedException ex) {}
        System.exit(0);
    }
    private JLabel college;
    private JLabel filesavedhere;
    private JLabel gpa;
    private JLabel gpatxt;
    private JButton closebutton;
    private JLabel resultslabel;
    private JLabel quizavg;
    private JLabel lettergrade;
    private JLabel lettergradetxt;
    private JLabel overallavg;
    private JLabel overallavgtxt;
    private JLabel quizavgtxt;
    private JLabel testavg;
    private JLabel testavgtxt;
    private JLabel withhonors;
}