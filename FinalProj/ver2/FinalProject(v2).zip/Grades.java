import javax.swing.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class Grades {
    static String studentName;
    static String collegeName;
    static float test1;
    static float test2;
    static float test3;
    static float test4;
    static float quiz1;
    static float quiz2;
    static float quiz3;
    static float quiz4;
    static float hwGrade;
    static float attendanceGrade;


    public static float getTestAverage() {
        return (test1 + test2 + test3 + test4) / 4;
    }

    public static float getQuizAverage() {
        return (quiz1 + quiz2 + quiz3 + quiz4) / 4;
    }

    public static float getOverallGrade() {
        return (float) ((getTestAverage() * .6) + (getQuizAverage() * .2) + (hwGrade * .1) + (attendanceGrade * .1));
    }

    public static char getLetterGrade(float overallavg) {
        if (overallavg >= 90) return 'A';
        else if (overallavg >= 80) return 'B';
        else if (overallavg >= 70) return 'C';
        else if (overallavg >= 60) return 'D';
        else return 'F';
    }

    public static int getGPA(char letter) {
        switch (letter) {
            case 'A' -> {
                return 4;
            }
            case 'B' -> {
                return 3;
            }
            case 'C' -> {
                return 2;
            }
            case 'D' -> {
                return 1;
            }
            case 'F' -> {
                return 0;
            }
        }
        return letter;
    }

    public static String saveResults() {
        try {
            FileWriter fw = new FileWriter("results.txt");
            fw.write("Student name: " + studentName +
                "\nCollege name: " + collegeName +
                "\nTest average: " + getTestAverage() +
                "\nQuiz average: " + getQuizAverage() +
                "\nOverall average: " + getOverallGrade() +
                "\nLetter grade: " + getLetterGrade(getOverallGrade()) +
                "\nGPA: " + getGPA(getLetterGrade(getOverallGrade())));
            fw.close();
        }
        catch (IOException e) {return "Error saving results to file";}
        return "These results have been saved to results.txt";
    }
    public static File pickFile(JDialog parent, char opensave) {
        try {
            if (opensave == 'o') {
                NewInputWindow.chooser.setDialogTitle("Choose a student information file to open");
                NewInputWindow.chooser.showOpenDialog(parent);
            }
            else {
                NewInputWindow.chooser.setDialogTitle("Choose where to save the student information file");
                NewInputWindow.chooser.showSaveDialog(parent);
            }

            return NewInputWindow.chooser.getSelectedFile();
        }
        catch (NullPointerException e) {
            return null;
        }
    }
    public static void readFile(JDialog parent, File file) {
        if (file != null) {
            try {
                Scanner reader = new Scanner(file);
                studentName = reader.nextLine().split(":")[1];
                collegeName = reader.nextLine().split(":")[1];
                test1 = Float.parseFloat(reader.nextLine().split(":")[1]);
                test2 = Float.parseFloat(reader.nextLine().split(":")[1]);
                test3 = Float.parseFloat(reader.nextLine().split(":")[1]);
                test4 = Float.parseFloat(reader.nextLine().split(":")[1]);
                quiz1 = Float.parseFloat(reader.nextLine().split(":")[1]);
                quiz2 = Float.parseFloat(reader.nextLine().split(":")[1]);
                quiz3 = Float.parseFloat(reader.nextLine().split(":")[1]);
                quiz4 = Float.parseFloat(reader.nextLine().split(":")[1]);
                hwGrade = Float.parseFloat(reader.nextLine().split(":")[1]);
                attendanceGrade = Float.parseFloat(reader.nextLine().split(":")[1]);
                parent.setVisible(false);
                reader.close();
                new NewIsCorrectWindow(parent).setVisible(true);
            }
            catch (FileNotFoundException | NumberFormatException e) {
                NewInputWindow.errorOccurred("filereaderror");
            }
        }
    }
    public static boolean writeFile(File file) {
        try {
            if (!file.toPath().endsWith(".txt")) file = new File(file.getPath() + ".txt");
            FileWriter fw = new FileWriter(file);
            fw.write("studentName:" + studentName +
                    "\ncollegeName:" + collegeName +
                    "\ntest1:" + test1 +
                    "\ntest2:" + test2 +
                    "\ntest3:" + test3 +
                    "\ntest4:" + test4 +
                    "\nquiz1:" + quiz1 +
                    "\nquiz2:" + quiz2 +
                    "\nquiz3:" + quiz3 +
                    "\nquiz4:" + quiz4 +
                    "\nhwGrade:" + hwGrade +
                    "\nattendanceGrade:" + attendanceGrade);
            fw.close();
        }
        catch (IOException e) {
            file.delete();
            NewInputWindow.errorOccurred("saveerror");
            return false;
        }
        return true;
    }
}
/*Phew! What a ride!*/