import java.awt.Color;

import javax.swing.*;

public class NewIsCorrectWindow extends JFrame {
    public NewIsCorrectWindow(JDialog myparent) {
        dialog = myparent;
        isOkLabel = new JLabel();
        yesButton = new JButton();
        noButton = new JButton();
        name = new JLabel();
        college = new JLabel();
        test1 = new JLabel();
        test2 = new JLabel();
        test3 = new JLabel();
        test4 = new JLabel();
        collegetext = new JLabel();
        nametext = new JLabel();
        test1text = new JLabel();
        test2text = new JLabel();
        test3text = new JLabel();
        test4text = new JLabel();
        quiz1 = new JLabel();
        quiz2 = new JLabel();
        quiz3 = new JLabel();
        quiz4 = new JLabel();
        hwgrade = new JLabel();
        attendance = new JLabel();
        attendancetext = new JLabel();
        hwgradetext = new JLabel();
        quiz4text = new JLabel();
        quiz3text = new JLabel();
        quiz2text = new JLabel();
        quiz1text = new JLabel();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        isOkLabel.setFont(new java.awt.Font("Segoe UI", 1, 24));
        isOkLabel.setHorizontalAlignment(SwingConstants.CENTER);
        isOkLabel.setText("Is this correct?");
        isOkLabel.setFocusable(false);

        yesButton.setText("Yes");
        yesButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sayOkAndShowNextWindow();
            }
        });

        noButton.setText("No");
        noButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                noClicked();
            }
        });

        name.setText("Name:");

        college.setText("College:");

        test1.setText("Test 1: ");

        test2.setText("Test 2: ");

        test3.setText("Test 3: ");

        test4.setText("Test 4: ");

        collegetext.setText(Grades.collegeName);

        nametext.setText(Grades.studentName);

        test1text.setText(String.valueOf(Grades.test1));

        test2text.setText(String.valueOf(Grades.test2));

        test3text.setText(String.valueOf(Grades.test3));

        test4text.setText(String.valueOf(Grades.test4));

        quiz1.setText("Quiz 1: ");

        quiz2.setText("Quiz 2: ");

        quiz3.setText("Quiz 3: ");

        quiz4.setText("Quiz 4: ");

        hwgrade.setText("HW Grade: ");

        attendance.setText("Attendance: ");

        attendancetext.setText(String.valueOf(Grades.attendanceGrade));

        hwgradetext.setText(String.valueOf(Grades.hwGrade));

        quiz4text.setText(String.valueOf(Grades.quiz4));

        quiz3text.setText(String.valueOf(Grades.quiz3));

        quiz2text.setText(String.valueOf(Grades.quiz2));

        quiz1text.setText(String.valueOf(Grades.quiz1));
        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Check information");


        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(isOkLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                        .addGroup(layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(name)
                                                .addGap(18, 18, 18)
                                                .addComponent(nametext))
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(college)
                                                .addGap(12, 12, 12)
                                                .addComponent(collegetext))
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(test1)
                                                .addGap(18, 18, 18)
                                                .addComponent(test1text))
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(test2)
                                                .addGap(18, 18, 18)
                                                .addComponent(test2text))
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(test3)
                                                .addGap(18, 18, 18)
                                                .addComponent(test3text))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(yesButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                        .addComponent(test4)
                                                        .addGap(18, 18, 18)
                                                        .addComponent(test4text))))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(30, 30, 30)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(quiz1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(quiz2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(quiz3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(quiz4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(hwgrade, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(attendance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGap(18, 18, 18)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(quiz1text)
                                                        .addComponent(quiz2text)
                                                        .addComponent(quiz3text)
                                                        .addComponent(quiz4text)
                                                        .addComponent(hwgradetext)
                                                        .addComponent(attendancetext))
                                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(noButton, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(35, 35, 35))))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(isOkLabel)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(name)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(nametext)
                                                .addComponent(quiz1)
                                                .addComponent(quiz1text)))
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(college)
                                        .addComponent(collegetext)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(quiz2)
                                                .addComponent(quiz2text)))
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(test1)
                                        .addComponent(test1text)
                                        .addComponent(quiz3)
                                        .addComponent(quiz3text))
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(test2)
                                        .addComponent(test2text)
                                        .addComponent(quiz4)
                                        .addComponent(quiz4text))
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(test3)
                                        .addComponent(test3text)
                                        .addComponent(hwgrade)
                                        .addComponent(hwgradetext))
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(test4)
                                        .addComponent(test4text)
                                        .addComponent(attendance)
                                        .addComponent(attendancetext))
                                .addGap(52, 52, 52)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(yesButton)
                                        .addComponent(noButton))
                                .addGap(13, 13, 13))
        );
        pack();
    }
    public void sayOkAndShowNextWindow() {
        isOkLabel.setText("OK, let's do it!!");
        isOkLabel.setForeground(new Color(0, 128, 0));
        isOkLabel.paintImmediately(isOkLabel.getVisibleRect());
        try {Thread.sleep(2000);}
        catch (InterruptedException e) {}
        this.dispose();
        new NewResultsWindow().setVisible(true);
    }
    public void noClicked() {
        this.dispose();
        dialog.setVisible(true);
    }
    private JLabel attendancetext;
    private JLabel college;
    private JLabel collegetext;
    private JLabel hwgradetext;
    private JLabel isOkLabel;
    private JLabel hwgrade;
    private JLabel attendance;
    private JLabel name;
    private JLabel nametext;
    private JButton noButton;
    private JLabel quiz1;
    private JLabel quiz1text;
    private JLabel quiz2;
    private JLabel quiz2text;
    private JLabel quiz3;
    private JLabel quiz3text;
    private JLabel quiz4;
    private JLabel quiz4text;
    private JLabel test1;
    private JLabel test1text;
    private JLabel test2;
    private JLabel test2text;
    private JLabel test3;
    private JLabel test3text;
    private JLabel test4;
    private JLabel test4text;
    private JButton yesButton;
    private JDialog dialog;
}